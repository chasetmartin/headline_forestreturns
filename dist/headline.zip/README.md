# Headline_forestreturns

Headline is a [Ghost](https://github.com/TryGhost/Ghost) theme built from the ground up for local news.
Headline_forestreturns is a customized version of Headline built for The Forest Returns blog.

# Timeline
This repository is a rif on the Headline theme that includes a timeline custom template for displaying Ghost blog posts in a timeline format. Find the example timeline template in the "and-then.hbs" Handlebars template.
